
package lab4_3;

public class TimeInterval {
    public int start ;
    public int end ;
    public TimeInterval(int s,int e){
    start = s;
    end = e;
    }
public int getHours (){
    int s = ((start / 100) * 60) + start %100;
    int e = ((end / 100) * 60) + end % 100;
    int sum = Math.abs(s-e) /60;
    return sum;
   }
public int getMinutes (){
    int s = start % 100;
    int e = end %100;
    int sum = s-e;
    return Math.abs(sum);
}
}
