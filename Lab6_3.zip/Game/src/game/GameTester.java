
package game;
public class GameTester {
    public static void main(String [] args){
        Game game = new Game();
        game.play();
    }
}
