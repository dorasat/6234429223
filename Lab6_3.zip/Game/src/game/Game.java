
package game;
import java.util.Scanner;
import java.util.Random;
public class Game {
    public void play(){
        int u = 0;
        int c = 0;
        int count = 0;
        Scanner input = new Scanner(System.in);
        Random ran = new Random();
        while (count < 2) {
                System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
                String user = input.next();
                if  ( "0".equals(user) || "1".equals(user) || "2".equals(user)  ){
                int us = Integer.parseInt(user);
                int com = ran.nextInt(3);
                if (us == com) {
                    String a = "";
                    if (us == 0) {
                        a = "ROCK";
                    }
                    if (us == 1) {
                        a = "PAPER";
                    }
                    if (us == 2) {
                        a = "SCISSORS";
                    }
                    System.out.println("You enter : " + a);
                    System.out.println("Computer : " + a);
                    System.out.println("It's a tie.");
                } else if (us == 0 && com == 1) {
                    System.out.println("You enter : ROCK");
                    System.out.println("Computer : PAPER");
                    System.out.println("You lose!");
                    c += 1;
                    count = Math.abs(u - c);
                } else if (us == 1 && com == 2) {
                    System.out.println("You enter : PAPER");
                    System.out.println("Computer : SCISSORS");
                    System.out.println("You lose!");
                    c += 1;
                    count = Math.abs(u - c);
                } else if (us == 2 && com == 0) {
                    System.out.println("You enter : SCISSORS");
                    System.out.println("Computer : ROCK");
                    System.out.println("You lose!");
                    c += 1;
                    count = Math.abs(u - c);
                } else if (us == 0 && com == 2) {
                    System.out.println("You enter : ROCK");
                    System.out.println("Computer : SCISSORS");
                    System.out.println("You win!");
                    u += 1;
                    count = Math.abs(u - c);
                } else if (us == 1 && com == 0) {
                    System.out.println("You enter : PAPER");
                    System.out.println("Computer : ROCK");
                    System.out.println("You win!");
                    u += 1;
                    count = Math.abs(u - c);
                } else if (us == 2 && com == 1) {
                    System.out.println("You enter : SCISSORS");
                    System.out.println("Computer : PAPER");
                    System.out.println("You win!");
                    u += 1;
                    count = Math.abs(u - c);
                }
            }    
        }
        if (u > c){
            System.out.println("----------------------------------------"+"\n"+"Congrats! You win.");
            System.out.println("User Score: "+u);
            System.out.println("Computer Score: "+c);

        }
        else{
            System.out.println("----------------------------------------"+"\n"+"Too bad! You lose.");
            System.out.println("User Score: "+u);
            System.out.println("Computer Score: "+c);
        }
    }
}
