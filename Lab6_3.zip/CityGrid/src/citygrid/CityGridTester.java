package citygrid;

public class CityGridTester {
    public static void main(String [] args){
        CityGrid city = new CityGrid(10);
        double avg = 0;
        int num = 0;
        int max = 0;
        for (num=0;num <= 10000;num++){
            city.walk();
            
            avg = avg + city.counter();  
            if (city.counter() > max)
                max = city.counter();
            city.reset();    
            }

        double a = avg / 10000;
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n", a);
        System.out.println("Maximum number of steps that a person can take and is still in the city: " + max);
    }    
}    

