package citygrid;

import java.util.Random;
public class CityGrid {
    private int xCoor;
    private int yCoor;
    private int gridSize;
    private int check;


    public CityGrid(int walk){
        gridSize = walk;
        xCoor = walk/2;
        yCoor = xCoor;
    }

    public void walk(){

        Random random = new Random();
        int count = 0;
         xCoor = gridSize/2;
         yCoor = xCoor;
            while (count<1000){
                int ran = random.nextInt(4)+1;
                if (ran == 1){
                    xCoor += 1;
                }
                else if (ran == 2){
                    xCoor -= 1;
                }
                else if (ran == 3){
                    yCoor += 1;
                }
                else if (ran == 4){
                    yCoor -= 1;
                }
                if(xCoor > gridSize || yCoor > gridSize || xCoor < 0 || yCoor < 0  ){
                    break;
                }
                count+=1;

            }
        if (count < 1000)
            check = count;
    }

    public boolean isInCity(){
          if (xCoor < gridSize || yCoor < gridSize || xCoor > 0 || yCoor > 0)
              return true;
          else
              return false;
    }

    public void reset(){
        xCoor = gridSize/2;
        yCoor = xCoor;
    }

    public int counter(){
        return  check;
    }

}