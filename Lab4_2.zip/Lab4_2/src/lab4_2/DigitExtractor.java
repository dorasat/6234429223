
package lab4_2;

public class DigitExtractor {
    private int number;
    private int remain;
    public DigitExtractor (int an_int){
        number = an_int;
    }
public int nextDigit(){
    int num = number %10;
    remain = number / 10;
    number = remain ;
    return num;
    }
}
