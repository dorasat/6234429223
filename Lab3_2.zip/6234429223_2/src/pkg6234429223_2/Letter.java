
package pkg6234429223_2;

public class Letter {
    public String name1;
    public String name2;
    public String s;
    public Letter(String from,String to){
        name1 = from;
        name2 = to;
    }
    public void addline(String line){
        s = line;
    }
    public String getText(){
        return "Dear "+name1+":"+"\n\n"+s+"\n\n"+"Sincerely,"+"\n\n"+name2;
    }
}
