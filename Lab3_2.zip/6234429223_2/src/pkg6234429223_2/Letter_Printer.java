
package pkg6234429223_2;

public class Letter_Printer {
   public static void main(String[] args) {
       Letter let = new Letter("Jade","Clarissa");
       let.addline("We must find Simon quickly."+"\n"+ "He might be in danger.");
       System.out.println(let.getText());
    }
}
