
package lab2_3;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Lab2_3 {

    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(2001,Calendar.JANUARY,29);
        cal.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        System.out.println("" + cal.get(Calendar.DAY_OF_WEEK)+ " " + cal.get(Calendar.DAY_OF_MONTH) + " "+ (1 + cal.get(Calendar.MONTH))+ " " + cal.get(Calendar.YEAR));
        System.out.println("" + myBirthday.get(Calendar.DAY_OF_WEEK)+ " " + myBirthday.get(Calendar.DAY_OF_MONTH) + " "+ (1 + myBirthday.get(Calendar.MONTH))+ " " + myBirthday.get(Calendar.YEAR));
    }
}