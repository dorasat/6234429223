
package pkg6234429223_1;

public class InsectPopulation {
    public double population;
    public InsectPopulation (int num){
            population = num;
        }
    public void breed(){
        population = 2*population;
    }
    public void spray(){
        population = population - (population * 0.1);
    }
    public double getNumInsect(){
        return population;
    }
}


