
package pkg6234429223_1;

public class InsectPopulationTester {
    public static void main(String[] args){
        InsectPopulation insect = new InsectPopulation(10);
        insect.breed();
        insect.spray();
        System.out.println("Nuber of Insect : "+insect.getNumInsect());
        insect.breed();
        insect.spray();
        System.out.println("Nuber of Insect : "+insect.getNumInsect());
        insect.breed();
        insect.spray();
        System.out.printf("Nuber of Insect : %.2f",insect.getNumInsect());
    }
}
