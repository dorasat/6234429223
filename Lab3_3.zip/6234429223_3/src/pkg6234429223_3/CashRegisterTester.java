
package pkg6234429223_3;

public class CashRegisterTester {
    public static void main(String[] args){
        CashRegister cash = new CashRegister(7);
        cash.recordTaxablePurchase(20);
        cash.recordPurchase(50);
        cash.recordPurchase(10);
        System.out.printf("Your change is %.1f\n",cash.giveChange(100));
        System.out.printf("Your total tax is %.1f\n",cash.getTotalTax());
    }
}
