
package pkg6234429223_3;

public class CashRegister {
    public double tax;
    public double cost_tax;
    public double cost;
    public double total_tax;
    public CashRegister (int tax2){
        double tax3 = tax2;
        tax = tax3/100;
    }
    public void recordTaxablePurchase(double price){
        total_tax = tax*cost;
        price = price + (tax*price);
        cost_tax += price; 
    }
    public void recordPurchase(double price2){
        cost += price2;
    }
    public double giveChange(double money){
        double change = money - (cost_tax + cost);
        return change;
    }
    public double getTotalTax (){
        return total_tax;
    }
}
