
package lab4_1;

import java.util.Scanner;

public class SodaTester {
    public static void main(String[] args) {
        Scanner scan = new Scanner (System.in);
        System.out.print("Enter height : ");
        double height;
        height = scan.nextDouble();
        System.out.print("Enter diameter : ");
        double center ;
        center = scan.nextDouble();
        SodaCan test = new SodaCan(height , center );
        double volume = test.getVolume();
        System.out.printf("Volume : %.2f\n",volume);
        double surface_area = test.getSurfaceArea();
        System.out.printf("Surface area : %.2f\n",surface_area);
    }
}


    