
package lab4_1;

public class SodaCan {
    public double height ;
    public double center ;
    public SodaCan (double h,double d){
        height = h;
        center = d;
    }
    public double getVolume (){
        double V = (center/2) * (center/2) * Math.PI * height;
        return V;
    }
    public double getSurfaceArea (){
        double area = (2 * Math.PI * (center/2) * height) + (2 * Math.PI * (center/2) * (center/2));
        return area ;
    }
}

