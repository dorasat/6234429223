
package HollePrintor;

public class HollePrintor {
    public static void main (String[] args ){
        String x = "Hello, World!" ;
        x = x.replace('e', 'x');
        x = x.replace('o', 'e');
        x = x.replace('x', 'o');
       System.out.println(x);
    }
}
