
package CannonBall;

public class CannonBall {
    private double initV ;
    private double simS;
    private double simT;
    private double keepInitV;
    public static final double g = 9.81;

    public CannonBall(double initV) {
        this.initV = initV;
        keepInitV = initV;
    }

    public void simulatedFlight() {
        double t = 0.01;
        int count =0;
        double ds = 0;
        int c = 0;
        while (initV > 0) {
            ds = initV * t;
            simS = simS + ds;        
            initV = initV - (g * t );              
            count += 1;
            if (count % 100 == 0){
               c += 1; 
               System.out.printf("Distance on " +  c + " sec: %.3f\n",simS);
            }   
        simT = count;
        }
        simT = simT / 100;
        System.out.printf("Final distance: %.3f Total time: %.2f \n",simS,simT);
    }

    public double calculusFlight(double t){
        //s(t) = -0.5*g*t2 + v0*t โดย g = 9.81 m/sec2
        double distance = (-0.5 * 9.81 * (t*t)) + (keepInitV * t );
        return distance;
        
    }

    public double getSimulatedTime(){
        return simT ;
    }

    public double getSimulatedDistance(){
        return simS;            
    }
}
